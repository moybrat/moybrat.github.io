import "../style/default.sass";
import InstaValidator from "./instavalidator";

const input = document.getElementById("insta-input"),
    btn = document.getElementById("btn"),
    result = document.getElementById("result");

const pattern1 = /^(https?:\/\/|www\.)\w*\.\w*/;
const pattern2 = /instagram\.com\/\w*/;
const pattern3 = /^\w{4,30}$/;

const validator = new InstaValidator(result)

btn.onclick = (e) => {
    e.preventDefault();
    validator.check(input.value);
}
