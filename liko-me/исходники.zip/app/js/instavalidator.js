export default class InstaValidator {
    constructor(domElem) {
        this.field = domElem;
        this.check = this.check.bind(this);
        this.patterns = {
            link: /^(?:https?:\/\/|www\.)?(?:\w+|instagram)\.\w+/,
            linkInsta: /instagram\.com\/\w*/,
            login: /^\w{4,30}$/,
            loginLink: /(?:.*)?instagram\.com\/([^\/]*)(?:.*)/
        }
    }

    check(str) {
        if (!str) return;
        this.field.innerHTML = "";
        // ПРоверка: является ли строка ссылкой
        if (this.patterns.link.test(str)) {
            // Если является ссылкой
            // Проверяем является ли это ссылкой на сайт инстаграмма
            if (this.patterns.linkInsta.test(str)) {
                // Если является ссылкой на сайт инстаграмма
                // В ссылке находим логин и проверяем его на валидность
                const login = str.replace(this.patterns.loginLink, "$1");
                if(this.patterns.login.test(login)){
                    this.output(str);
                } else {
                    this.err("Неправильный логин");
                }
            } else {
                this.err("Неправильная ссылка");
            }
        } else if (this.patterns.login.test(str)) {
            this.output("https://www.instagram.com/"+str);
        } else {
            this.err("Неправильный логин");
        }
    }

    err(msg) {
        const h3 = document.createElement("h3");
        const p = document.createElement("p");
        h3.innerHTML = "Ошибка";
        p.innerHTML = msg;
        this.field.append(h3);
        this.field.append(p);
    }

    output(msg){
        const h3 = document.createElement("h3");
        h3.innerHTML = "Ссылка";
        const a = document.createElement("a");
        if(/http/.test(msg)){
            a.setAttribute("href", msg);
        } else {
            a.setAttribute("href", "https://"+msg);
        }
        a.innerHTML = msg;
        this.field.append(h3);
        this.field.append(a);
    }

}